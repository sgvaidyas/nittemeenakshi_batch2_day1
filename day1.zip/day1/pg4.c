#include<stdio.h>

void main()
{
	int i,n;
	printf("Enter n = ");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
		printf("%0.0f ",pow(2,i));
	
}
