//Program to find out minimum of 3 elements
#include<stdio.h>

void main()
{
	int a,b,c;
	printf("enter the values of a b and c");
	scanf("%d%d%d",&a,&b,&c);
	if(a<b && a<c)
		printf("A = %d is smaller",a);
	else if(b<a && b<c)
		printf("B = %d is smaller",b);
	else
		printf("C = %d is smaller",c);
}
