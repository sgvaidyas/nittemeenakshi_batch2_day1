#include<stdio.h>

void main()
{
	int i,j,n;
	printf("Enter n = ");
	scanf("%d",&n);
/*	
	for(i=1,j=n; i<=n ; i++,j--)
		printf("%d\n",i*j);
		*/
		
	for(i=1;i<=n;i++)
		printf("%d  ",(i*(n-i+1)));
}
